import contract from './contract'; 
import web3 from './web3';

